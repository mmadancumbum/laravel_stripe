-- MariaDB dump 10.19  Distrib 10.4.21-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: laravel_stripe
-- ------------------------------------------------------
-- Server version	10.4.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'incidunt',16913,'Molestias libero doloribus aspernatur id in. Ex mollitia voluptatem et explicabo qui eum.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(2,'et',7444,'Dolorum fuga tenetur quas in est dolor. Ut dolorem maxime dolorum sed perferendis vitae. Explicabo a sed iste accusamus aut aut velit. Tempore sit voluptates inventore quo.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(3,'rem',8203,'Unde quidem molestiae sint veritatis et eligendi adipisci. Deleniti eaque occaecati voluptatibus enim ut ut. Magnam sunt nobis ut ipsam.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(4,'iure',8082,'Vitae suscipit ad illum atque eius nostrum. Expedita animi a nihil voluptatem inventore illo rerum ipsa. Sunt rem soluta earum hic vero voluptates.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(5,'est',7047,'Vel amet doloremque dicta aut dolor labore. Corporis voluptates debitis mollitia blanditiis. Commodi esse libero et adipisci illum quisquam. Ullam architecto ipsam nam et.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(6,'veniam',11121,'Ea possimus quos libero est voluptatum dolore. Nihil ut ut accusamus qui. Aliquam tempora aut veniam ad non neque animi. Praesentium dolorem ipsam aliquam id.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(7,'et',8003,'Voluptas et voluptatem possimus porro nostrum. Expedita sit dolor dolores ea similique nam.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(8,'vitae',5973,'Quo dolores quaerat est enim ut est. Commodi dolorem corporis rerum error. Ducimus suscipit sed recusandae magni expedita architecto. Doloremque unde dolorum eum magnam aut.','2022-09-11 05:24:07','2022-09-11 05:24:07'),(9,'suscipit',10118,'Optio minus temporibus qui veritatis aut. Laudantium quis minima qui tempora odit ipsa doloribus. Inventore amet numquam sed odio dolorum unde deserunt.','2022-09-11 05:24:08','2022-09-11 05:24:08'),(10,'velit',1783,'Debitis repellendus aut quia mollitia repudiandae. Sed voluptatum maxime itaque delectus. Sunt amet eos illo. Nemo eligendi rerum est natus non quos corrupti porro.','2022-09-11 05:24:08','2022-09-11 05:24:08');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-11 17:03:02
